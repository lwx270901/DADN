package dashboard.iot.bku.roomcontrol;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


import com.github.mikephil.charting.charts.LineChart;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ADMIN on 3/22/2022.
 */

public class FragmentStatistic extends Fragment {

//    LineChart lineChart;
    GraphView graphView;
    GraphView graphView1;
    GraphView graphView2;
    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
//    LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[0]);
//Graph
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.layout_fragment_statistic, container, false);
//        lineChart = view.findViewById(R.id.TempLine);

        graphView = view.findViewById(R.id.TempLine);
        ((RoomService)getActivity()).addSer(graphView);


        //addTest
        graphView1 = view.findViewById(R.id.HumiLine);
        ((RoomService)getActivity()).addSer1(graphView1);



//        graphView.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter()
//        {
//            @Override
//            public String formatLabel(double value, boolean isValuex)
//            {
//                if(isValuex)
//                {
//                    return sdf.format(new Date((long)value));
//                }
//                else
//                {
//                    return super.formatLabel(value, isValuex);
//                }
//            }
//        });

        return view;
    }
}
