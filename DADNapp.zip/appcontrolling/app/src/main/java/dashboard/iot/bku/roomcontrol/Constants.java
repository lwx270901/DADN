package dashboard.iot.bku.roomcontrol;

/**
 * Created by ADMIN on 3/22/2022.
 */

public class Constants {
    public static final int ROOM_FRAGMENT_INDEX = 0;
    public static final int STATISTIC_FRAGMENT_INDEX = 1;
}
