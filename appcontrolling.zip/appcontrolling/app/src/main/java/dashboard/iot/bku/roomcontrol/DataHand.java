package dashboard.iot.bku.roomcontrol;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ADMIN on 4/19/2022.
 */

public class DataHand extends SQLiteOpenHelper {

    public DataHand(Context context) {
        super(context, "Database2", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CreateTable = "create table Table2 (xValue REAL, yValue REAL)";
        db.execSQL(CreateTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertToData(long ValX, float ValY)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("xValue", ValX);
        contentValues.put("yValue", ValY);

        database.insert("Table2", null,contentValues);
    }
}
