package dashboard.iot.bku.roomcontrol;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by ADMIN on 3/28/2022.
 */

public class MyHelper extends SQLiteOpenHelper {

    public MyHelper(Context context) {
        super(context, "MyDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "create table myTable(xValues REAL, yValues REAL);";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {



    }

    public Boolean insertData(long valueX, float valueY ){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();


        contentValues.put("xValues", valueX);
        contentValues.put("yValues", valueY);
        sqLiteDatabase.insert("myTable", null, contentValues);
        return true;
    }

}
